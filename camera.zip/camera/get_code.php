<?php
// Use local XAMPP
$conn = mysqli_connect('localhost', 'root', '', 'smart_security');

if (!$conn) {
    echo "0"; // Return 0 if connection fails
    exit;
}

// Check for recent detection
$result = mysqli_query($conn, "SELECT person_detected FROM detection_log 
                               WHERE detected_at >= NOW() - INTERVAL 30 SECOND 
                               ORDER BY id DESC LIMIT 1");
if($row = mysqli_fetch_assoc($result)){
    echo $row['person_detected'];
} else {
    // Fallback to code table
    $result2 = mysqli_query($conn, "SELECT code FROM `code` ORDER BY id DESC LIMIT 1");
    if($row2 = mysqli_fetch_assoc($result2)){
        echo $row2['code'];
    } else {
        echo "0";
    }
}
?>