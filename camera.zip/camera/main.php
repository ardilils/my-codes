<?php
date_default_timezone_set("Africa/Nairobi");
$conn = mysqli_connect('localhost', 'root', '', 'smart_security');

if (!$conn) {
    http_response_code(500);
    echo "Database connection failed";
    exit;
}

// Check if 'code' table exists, if not create it (for backward compatibility)
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `code` (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code TINYINT(1) DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

// Insert default record if table is empty
$check = mysqli_query($conn, "SELECT * FROM `code` LIMIT 1");
if(mysqli_num_rows($check) == 0){
    mysqli_query($conn, "INSERT INTO `code` (code) VALUES (0)");
}

// Create other tables if they don't exist (add this for completeness)
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS detection_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    detected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    person_detected TINYINT(1) NOT NULL,
    confidence_score FLOAT,
    camera_position VARCHAR(50) DEFAULT 'main'
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    log_type VARCHAR(50) NOT NULL,
    message TEXT NOT NULL
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS sms_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    detection_id INT,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    phone_number VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'sent',
    api_response TEXT
)");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS siren_control (
    id INT AUTO_INCREMENT PRIMARY KEY,
    detection_id INT,
    activated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TINYINT(1) DEFAULT 0,
    triggered_by VARCHAR(50) DEFAULT 'auto'
)");

if(isset($_GET['code'])){
    $code = mysqli_real_escape_string($conn, $_GET['code']); // Prevent SQL injection
    
    // Log the detection
    $confidence = isset($_GET['confidence']) ? floatval($_GET['confidence']) : 0.8;
    $detection_time = date('Y-m-d H:i:s');
    
    $insert = "INSERT INTO detection_log (detected_at, person_detected, confidence_score, camera_position) 
               VALUES ('$detection_time', '$code', '$confidence', 'main')";
    mysqli_query($conn, $insert);
    $detection_id = mysqli_insert_id($conn);
    
    // Log system activity
    mysqli_query($conn, "INSERT INTO system_logs (log_type, message) 
                         VALUES ('detection', 'Person detection: $code at $detection_time')");
    
    if($code == "1"){
        // Send SMS - FIXED PHONE NUMBER
        $username   = "josephate";  
        $apiKey     = "atsk_1f83da099a53c8a08d34006a376cd4ea8b96cf656acb608f39f7315e4e6fcaa5f986805c";  
        $recipients = "+2547";  // <--- FIXED: Added your full phone number
        $message    = "Security alert! Your Camera has detected a person in your compound at ". date("H:i d/m/y");
        
        // Only send SMS if recipients is not empty
        if(!empty($recipients)){
            $url = "https://api.africastalking.com/version1/messaging";
            
            $data = http_build_query([
                'username'   => $username,
                'to'         => $recipients,
                'message'    => $message,
            ]);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Accept: application/json",
                "apikey: $apiKey"
            ]);

            $response = curl_exec($ch);
            $status = curl_errno($ch) ? 'failed' : 'sent';
            
            if(curl_errno($ch)){
                echo 'Curl error: ' . curl_error($ch);
            }
            
            curl_close($ch);
            
            // Log SMS alert
            mysqli_query($conn, "INSERT INTO sms_alerts (detection_id, phone_number, message, status, api_response) 
                                VALUES ('$detection_id', '$recipients', '$message', '$status', '$response')");
            
            echo " - SMS sent to $recipients";
        } else {
            // Log that SMS wasn't sent due to missing number
            mysqli_query($conn, "INSERT INTO system_logs (log_type, message) 
                                VALUES ('warning', 'SMS not sent - recipient number missing')");
            echo " - SMS not sent (no number)";
        }
        
        // Activate siren
        mysqli_query($conn, "INSERT INTO siren_control (detection_id, status, triggered_by) 
                            VALUES ('$detection_id', '1', 'auto')");
    }
    
    // Update the code table (keeping compatibility)
    mysqli_query($conn, "UPDATE `code` SET `code`='$code' ORDER BY id DESC LIMIT 1");
    echo "received ".$code;
}
?>