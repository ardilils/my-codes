<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $department = $_POST['department']; 
    $positions = $_POST['positions'];
    $deadline = $_POST['deadline'];
    $status = 'open';

    $stmt = $conn->prepare("INSERT INTO opportunities (title, department, positions, deadline, status) VALUES (?, ?, ?, ?, ?)");

    if (!$stmt) {
        die("<div class='message error'>Prepare failed: " . $conn->error . "</div>");
    }

    $stmt->bind_param("sssss", $title, $department, $positions, $deadline, $status);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<div class='message success'>✅ Opportunity submitted successfully.</div>";
    } else {
        echo "<div class='message error'>❌ Failed to submit opportunity.</div>";
    }

    $stmt->close();
    $conn->close();
}
?>

<a href="logout.php" class="logout-btn">Logout</a>

<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f8;
        margin: 0;
        padding: 20px;
    }

    .message {
        max-width: 500px;
        margin: 20px auto;
        padding: 15px;
        border-radius: 6px;
        text-align: center;
        font-size: 16px;
        font-weight: bold;
    }

    .message.success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .message.error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .logout-btn {
        display: block;
        width: max-content;
        margin: 20px auto;
        padding: 10px 20px;
        background: #007bff;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
    }

    .logout-btn:hover {
        background: #0056b3;
    }
</style>
