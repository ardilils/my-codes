<?php
session_start();
include 'db.php';
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = "";
$error = "";

// Handle OTP verification
if (isset($_POST['verify'])) {
    $entered_otp = trim($_POST['otp']);
    
    // Check OTP expiry
    if (time() > $_SESSION['otp_expiry']) {
        $error = "OTP expired. Please click 'Resend OTP'.";
    } elseif ($entered_otp == $_SESSION['otp']) {
        $email = $_SESSION['pending_email'];
        $password = $_SESSION['pending_password'];

        $stmt = mysqli_prepare($conn, "INSERT INTO users (email, password) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, 'ss', $email, $password);
        if (mysqli_stmt_execute($stmt)) {
            $message = "Verification successful. <a href='login.php'>Login now</a>.";
            session_unset();
        } else {
            $error = "Database error. Please try again.";
        }
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}

// Handle resend OTP
if (isset($_POST['resend'])) {
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_expiry'] = time() + (5 * 60); // OTP valid for 5 minutes
    if (sendOTP($_SESSION['pending_email'], $otp)) {
        $message = "A new OTP has been sent to your email.";
    } else {
        $error = "Failed to resend OTP. Try again later.";
    }
}

// Send OTP using Gmail SMTP
function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 0; // Change to 2 for debug logs
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'kateelilian22@gmail.com'; // Your Gmail
        $mail->Password = 'wpmzraqrwdvykfeg';     // App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('kateelilian22@gmail.com', 'MKSU Portal');
        $mail->addAddress($email);
        $mail->addReplyTo('kateelilian22@gmail.com', 'MKSU Portal');

        $mail->isHTML(true);
        $mail->Subject = 'MKSU Portal - Your OTP Code';
        $mail->Body = "<h3>Your OTP is: <strong>$otp</strong></h3><p>This code is valid for 5 minutes.</p>";
        $mail->AltBody = "Your OTP is: $otp (Valid for 5 minutes)";

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; padding: 40px; }
        .form-container { background: #fff; padding: 30px; max-width: 400px; margin: auto; border-radius: 10px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { width: 100%; padding: 12px; background: gold; color: #0b0f5b; font-weight: bold; border: none; border-radius: 5px; cursor: pointer; margin-top: 5px; }
        button:hover { background: #0b0f5b; color: gold; }
        .message { text-align: center; color: green; }
        .error { text-align: center; color: red; }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Verify OTP</h2>
    <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
        <input type="text" name="otp" placeholder="Enter OTP" required>
        <button type="submit" name="verify">Verify</button>
    </form>
    <form method="POST" style="margin-top:10px;">
        <button type="submit" name="resend">Resend OTP</button>
    </form>
</div>
</body>
</html>
