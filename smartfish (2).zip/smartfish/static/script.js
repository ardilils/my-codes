let chartInstance = null;

function submitManual() {
    const data = {
        temperature: document.getElementById("temperature").value,
        ph: document.getElementById("ph").value,
        oxygen: document.getElementById("oxygen").value,
        turbidity: document.getElementById("turbidity").value,
        ammonia: document.getElementById("ammonia").value,
        water_level: document.getElementById("water_level").value
    };

    fetch('/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        loadLatest();
    });
}

function simulateData() {
    fetch('/simulate')
    .then(res => res.json())
    .then(data => {
        alert("Simulated readings saved");
        loadLatest();
    });
}

function loadLatest() {
    fetch('/latest')
    .then(res => res.json())
    .then(data => {
        let alertsDiv = document.getElementById("alerts");
        alertsDiv.innerHTML = "";

        let labels = [];
        let values = [];

        data.reverse().forEach(item => {
            labels.push(item.parameter_name);
            values.push(item.value);

            let color = "green";
            if (item.status === "Low") color = "orange";
            if (item.status === "High" || item.status === "Not Normal") color = "red";

            alertsDiv.innerHTML += `
                <p style="color:${color}">
                    ${item.parameter_name}: ${item.value} ${item.unit} (${item.status})
                </p>
            `;
        });

        drawChart(labels, values);
    });
}

function drawChart(labels, values) {
    const ctx = document.getElementById('sensorChart').getContext('2d');

    if (chartInstance) chartInstance.destroy();

    chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sensor Values',
                data: values,
                backgroundColor: '#d4af37', // gold bars
                borderColor: '#b8962e',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: { color: "#000000" },
                    grid: { color: "#dddddd" }
                },
                x: { 
                    ticks: { color: "#000000" },
                    grid: { color: "#eeeeee" }
                }
            },
            plugins: {
                legend: { labels: { color: "#000000" } }
            }
        }
    });
}

window.onload = function() {
    loadLatest();
};
