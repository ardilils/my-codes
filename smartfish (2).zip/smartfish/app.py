from flask import Flask, render_template, request, jsonify
import pymysql

app = Flask(__name__)

# =====================================
# DATABASE CONNECTION
# =====================================
def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='smartfish_db',
        cursorclass=pymysql.cursors.DictCursor
    )

# =====================================
# UNIT HELPER FUNCTION
# =====================================
def get_unit(parameter):
    units = {
        "Temperature": "°C",
        "pH": "",
        "Oxygen": "mg/L",
        "Turbidity": "NTU",
        "Ammonia": "mg/L",
        "Water Level": "m"
    }
    return units.get(parameter, "")

# =====================================
# FAVOURABLE CONDITIONS (THRESHOLDS)
# =====================================
FAVOURABLE_CONDITIONS = {
    "Temperature": (24, 30),
    "pH": (6.5, 8.5),
    "Oxygen": (5, 8),
    "Turbidity": (10, 40),
    "Ammonia": (0, 0.02),
    "Water Level": (1.2, 1.8)
}

# =====================================
# EVALUATE FARMER READING
# =====================================
def evaluate_parameter(parameter, value):
    min_val, max_val = FAVOURABLE_CONDITIONS[parameter]
    if value < min_val:
        return "Too Low"
    elif value > max_val:
        return "Too High"
    else:
        return "Favourable"


# =====================================
# SAVE READINGS AND ALERTS
# =====================================
def save_readings(readings, mode="Manual"):
    connection = get_db_connection()
    cursor = connection.cursor()

    for parameter, value in readings.items():
        # Determine the status
        min_val, max_val = FAVOURABLE_CONDITIONS[parameter]
        if value < min_val:
            status = "Too Low"
        elif value > max_val:
            status = "Too High"
        else:
            status = "Favourable"

        # Get unit
        unit = get_unit(parameter)

        # Save the reading
        cursor.execute("""
            INSERT INTO sensor_readings
            (parameter_name, value, unit, status, reading_mode)
            VALUES (%s, %s, %s, %s, %s)
        """, (parameter, value, unit, status, mode))

        # Save alert only if not favourable
        if status != "Favourable":
            cursor.execute("""
                INSERT INTO alerts
                (parameter_name, reading_value, alert_level, alert_message)
                VALUES (%s, %s, %s, %s)
            """, (
                parameter,
                value,
                status,
                f"{parameter} is {status}! Immediate attention required."
            ))

    connection.commit()
    cursor.close()
    connection.close()

# =====================================
# HOME PAGE
# =====================================
@app.route('/')
def home():
    return render_template('index.html')

# =====================================
# MANUAL ENTRY ROUTE
# =====================================
@app.route('/manual', methods=['POST'])
def manual():
    data = request.json

    # Farmer inputs
    readings = {
        "Temperature": float(data['temperature']),
        "pH": float(data['ph']),
        "Oxygen": float(data['oxygen']),
        "Turbidity": float(data['turbidity']),
        "Ammonia": float(data['ammonia']),
        "Water Level": float(data['water_level'])
    }

    save_readings(readings, "Manual")

    # Return status for dashboard
    alert_status = {param: evaluate_parameter(param, val) for param, val in readings.items()}

    return jsonify({
        "message": "Manual readings saved successfully",
        "readings_status": alert_status
    })

# =====================================
# SIMULATED SENSOR ROUTE (OPTIONAL)
# =====================================
@app.route('/simulate')
def simulate():
    import random
    # Simulated readings (for testing only, not used for alerts)
    readings = {
        "Temperature": round(random.uniform(24, 30), 2),
        "pH": round(random.uniform(6.5, 8.5), 2),
        "Oxygen": round(random.uniform(5, 8), 2),
        "Turbidity": round(random.uniform(10, 40), 2),
        "Ammonia": round(random.uniform(0, 0.02), 3),
        "Water Level": round(random.uniform(1.2, 1.8), 2)
    }

    save_readings(readings, "Simulation")

    return jsonify(readings)

# =====================================
# GET LATEST READINGS
# =====================================
@app.route('/latest')
def latest():
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT * FROM sensor_readings
        ORDER BY recorded_at DESC
        LIMIT 6
    """)
    data = cursor.fetchall()
    cursor.close()
    connection.close()

    return jsonify(data)

# =====================================
# RUN APP
# =====================================
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
