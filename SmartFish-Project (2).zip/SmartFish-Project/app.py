from flask import Flask, render_template, Response, jsonify, request, send_file
import threading, random, time, datetime, mysql.connector, os

# --- Flask app ---
app = Flask(__name__, template_folder='templates')

# --- MySQL config (XAMPP defaults) ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'smartfish_db'
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

# --- Current sensor data (latest values) ---
current = {
    "temperature": 27.0,
    "ph": 7.2,
    "oxygen": 6.8,
    "fish_type": "Tilapia"
}

# --- Alert thresholds ---
THRESHOLDS = {
    "temperature_max": 31.0,
    "temperature_min": 20.0,
    "ph_min": 6.8,
    "ph_max": 8.5,
    "oxygen_min": 5.8
}

# --- Database helpers ---
def save_reading(temp, ph, oxy, fish_type):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO readings (temperature, ph, oxygen, fish_type, created_at)
            VALUES (%s, %s, %s, %s, %s)
        """, (temp, ph, oxy, fish_type, datetime.datetime.now()))
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        print("DB save error:", e)

def save_feed(fish_type, feed_amount):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO feeding (fish_type, feed_amount, feed_time)
            VALUES (%s, %s, %s)
        """, (fish_type, feed_amount, datetime.datetime.now()))
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        print("Feed save error:", e)

def raise_alert(alert_type, message):
    print("ALERT:", message)
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO alerts (alert_type, message, sent, created_at)
            VALUES (%s, %s, %s, %s)
        """, (alert_type, message, False, datetime.datetime.now()))
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        print("Alert save error:", e)

# --- Simulated fish-type detection (randomized for demo) ---
def detect_fish_type():
    fish_list = ["Tilapia", "Catfish", "Goldfish", "Trout"]
    return random.choice(fish_list)

# --- Background simulated sensor thread ---
def sensor_loop():
    while True:
        temp = round(random.uniform(25.0, 32.0), 2)
        ph = round(random.uniform(6.4, 8.0), 2)
        oxy = round(random.uniform(5.0, 8.5), 2)
        fish_type = detect_fish_type()

        current.update({
            "temperature": temp,
            "ph": ph,
            "oxygen": oxy,
            "fish_type": fish_type
        })

        save_reading(temp, ph, oxy, fish_type)

        # Threshold checks
        if temp > THRESHOLDS['temperature_max']:
            raise_alert("Temperature", f"High temperature: {temp}°C")
        if temp < THRESHOLDS['temperature_min']:
            raise_alert("Temperature", f"Low temperature: {temp}°C")
        if ph < THRESHOLDS['ph_min'] or ph > THRESHOLDS['ph_max']:
            raise_alert("pH", f"pH out of range: {ph}")
        if oxy < THRESHOLDS['oxygen_min']:
            raise_alert("Oxygen", f"Low oxygen level: {oxy} mg/L")

        time.sleep(8)

threading.Thread(target=sensor_loop, daemon=True).start()

# --- Video feed setup ---
try:
    import cv2
    camera = cv2.VideoCapture(0)
    def gen_frames():
        while True:
            success, frame = camera.read()
            if not success:
                time.sleep(0.1)
                continue
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            cv2.putText(frame, f"SmartFish Live - {ts}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
    VIDEO_AVAILABLE = True
except Exception as e:
    print("Camera not available:", e)
    VIDEO_AVAILABLE = False

# --- Flask Routes ---
@app.route('/')
def index():
    return render_template('index.html', video=VIDEO_AVAILABLE)

@app.route('/video_feed')
def video_feed():
    if not VIDEO_AVAILABLE:
        return send_file('static/no_camera.png', mimetype='image/png')
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/get_latest')
def api_latest():
    return jsonify(current)

@app.route('/api/feed', methods=['POST'])
def feed_fish():
    data = request.json
    fish_type = data.get('fish_type', current.get('fish_type', 'Tilapia'))
    feed_amount = float(data.get('feed_amount', 0.2))
    save_feed(fish_type, feed_amount)
    raise_alert("Feeding", f"{fish_type} fed {feed_amount} kg")
    return jsonify({"message": f"{fish_type} fed {feed_amount} kg successfully."})

@app.route('/history')
def history_page():
    return render_template('history.html')

@app.route('/feed_history')
def feed_history_page():
    return render_template('feed_history.html')

@app.route('/api/feed_history')
def api_feed_history():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT fish_type, feed_amount, feed_time FROM feeding ORDER BY feed_time DESC LIMIT 50")
        rows = cur.fetchall()
        cur.close()
        conn.close()
        data = [
            {
                "fish_type": r[0],
                "feed_amount": r[1],
                "feed_time": r[2].strftime('%Y-%m-%d %H:%M:%S')
            }
            for r in rows
        ]
        return jsonify(data)
    except Exception as e:
        print("feed_history error:", e)
        return jsonify([])

@app.route('/history_data')
def history_data():
    """Return JSON of last N readings for charting."""
    limit = int(request.args.get('limit', 50))
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT temperature, ph, oxygen, fish_type, created_at
            FROM readings
            ORDER BY created_at DESC
            LIMIT %s
        """, (limit,))
        rows = cur.fetchall()
        cur.close()
        conn.close()
        rows.reverse()
        data = []
        for r in rows:
            data.append({
                'temperature': float(r[0]),
                'ph': float(r[1]),
                'oxygen': float(r[2]),
                'fish_type': r[3],
                'timestamp': r[4].strftime('%Y-%m-%d %H:%M:%S')
            })
        return jsonify(data)
    except Exception as e:
        print("history_data error:", e)
        return jsonify([])

if __name__ == '__main__':
    app.run(debug=True)
